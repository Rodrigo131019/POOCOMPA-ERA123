using static tareamaria.ventas_de_producto;
using static tareamaria.ventas_de_producto.Producto;
using System.IO;


namespace tareamaria
{
    public partial class Form1 : Form
    {
        private List<Producto> listaCompras;
        public Form1()
        {
            InitializeComponent();
            listaCompras = new List<Producto>();
            CargarProductos();
            OcultarAtributos();

        }
        private void CargarProductos()
        {

            cmbProducto.Items.AddRange(new string[] { "Silla", "Polera", "Celular", "Televisor", "Colch�n", "Catre", "Zapatos", "Blusa", "Pantalones", "Mochila" });

            cmbMaterial.Items.AddRange(new string[] { "Madera", "Metal", "Pl�stico", "Textil" });
            cmbColor.Items.AddRange(new string[] { "Rojo", "Azul", "Verde", "Negro", "Blanco" });

            cmbTallaPolera.Items.AddRange(new string[] { "S", "M", "L", "XL" });
            cmbTallaZapato.Items.AddRange(new string[] { "36", "37", "38", "39", "40" });
            cmbTallaBlusa.Items.AddRange(new string[] { "S", "M", "L", "XL" });
            cmbTallaPantalon.Items.AddRange(new string[] { "S", "M", "L", "XL" });

            cmbTama�o.Items.AddRange(new string[] { "32 Pulgadas", "40 Pulgadas", "50 Pulgadas", "60 Pulgadas" });
            cmbTama�oColchon.Items.AddRange(new string[] { "Individual", "Matrimonial", "Queen", "King" });
            cmbTama�oCatre.Items.AddRange(new string[] { "Individual", "Matrimonial" });

            cmbModelo.Items.AddRange(new string[] { "iPhone 13", "iPhone 13 Pro", "iPhone 13 Pro Max", "iPhone 14", "iPhone 14 Pro", "iPhone 14 Pro Max" });

            cmbcolorPolera.Items.AddRange(new string[] { "Rojo", "Azul", "Verde", "Negro", "Blanco" });
            cmbColorBlusa.Items.AddRange(new string[] { "Rojo", "Azul", "Verde", "Negro", "Blanco" });
            cmbColorPantalon.Items.AddRange(new string[] { "Rojo", "Azul", "Verde", "Negro", "Blanco" });
            cmbColorMochila.Items.AddRange(new string[] { "Rojo", "Azul", "Verde", "Negro", "Blanco" });
        }
        private void OcultarAtributos()
        {

            lblMaterial.Visible = false;
            cmbMaterial.Visible = false;
            lblColor.Visible = false;
            cmbColor.Visible = false;

            lblModelo.Visible = false;
            cmbModelo.Visible = false;

            lblTallaPolera.Visible = false;
            cmbTallaPolera.Visible = false;
            lblColorPolera.Visible = false;
            cmbcolorPolera.Visible = false;


            lblTama�o.Visible = false;
            cmbTama�o.Visible = false;
            lblMarca.Visible = false;
            cmbMarca.Visible = false;

            lblMaterialColchon.Visible = false;
            cmbMaterialColchon.Visible = false;
            lblTama�oColchon.Visible = false;
            cmbTama�oColchon.Visible = false;

            lblMaterialCatre.Visible = false;
            cmbMaterialCatre.Visible = false;
            lblTama�oCatre.Visible = false;
            cmbTama�oCatre.Visible = false;


            lblColorZapato.Visible = false;
            cmbColorZapato.Visible = false;
            lblTallaZapato.Visible = false;
            cmbTallaZapato.Visible = false;

            lblColorBlusa.Visible = false;
            cmbColorBlusa.Visible = false;
            lblTallaBlusa.Visible = false;
            cmbTallaBlusa.Visible = false;

            lblColorPantalon.Visible = false;
            cmbColorPantalon.Visible = false;
            lblTallaPantalon.Visible = false;
            cmbTallaPantalon.Visible = false;

            lblColorMochila.Visible = false;
            cmbColorMochila.Visible = false;
            lblModeloMochila.Visible = false;
            cmbModeloMochila.Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProducto.SelectedItem == null)
            {
                return; // Si no hay nada seleccionado, salir del m�todo
            }
            OcultarAtributos();

            string producto = cmbProducto.SelectedItem.ToString();
            lblPrecio.Text = "Precio: ";
            txtPrecio.Clear();


            switch (producto)
            {
                case "Silla":
                    lblMaterial.Visible = true;
                    cmbMaterial.Visible = true;
                    lblColor.Visible = true;
                    cmbColor.Visible = true;
                    break;

                case "Polera":
                    lblTallaPolera.Visible = true;
                    cmbTallaPolera.Visible = true;
                    lblColorPolera.Visible = true;
                    cmbcolorPolera.Visible = true;
                    break;

                case "Celular":
                    lblModelo.Visible = true;
                    cmbModelo.Visible = true;
                    lblColor.Visible = true;
                    cmbColor.Visible = true;
                    break;

                case "Televisor":
                    lblTama�o.Visible = true;
                    cmbTama�o.Visible = true;
                    lblMaterial.Visible = true;
                    cmbMaterial.Visible = true;
                    break;

                case "Colch�n":
                    lblTama�oColchon.Visible = true;
                    cmbTama�oColchon.Visible = true;
                    lblMaterialColchon.Visible = true;
                    cmbMaterialColchon.Visible = true;
                    break;

                case "Catre":
                    lblMaterialCatre.Visible = true;
                    cmbMaterialCatre.Visible = true;
                    lblTama�oCatre.Visible = true;
                    cmbTama�oCatre.Visible = true;
                    break;

                case "Zapatos":
                    lblTallaZapato.Visible = true;
                    cmbTallaZapato.Visible = true;
                    lblColorZapato.Visible = true;
                    cmbColorZapato.Visible = true;
                    break;

                case "Blusa":
                    lblTallaBlusa.Visible = true;
                    cmbTallaBlusa.Visible = true;
                    lblColorBlusa.Visible = true;
                    cmbColorBlusa.Visible = true;
                    break;

                case "Pantalones":
                    lblTallaPantalon.Visible = true;
                    cmbTallaPantalon.Visible = true;
                    lblColorPantalon.Visible = true;
                    cmbColorPantalon.Visible = true;
                    break;

                case "Mochila":
                    lblModeloMochila.Visible = true;
                    cmbModeloMochila.Visible = true;
                    lblColorMochila.Visible = true;
                    cmbColorMochila.Visible = true;
                    break;
            }
        }

        private void btnComprar_Click(object sender, EventArgs e)
        {
            if (cmbProducto.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un producto.");
                return;
            }

            if (!decimal.TryParse(txtPrecio.Text, out decimal precio))
            {
                MessageBox.Show("Por favor, ingrese un precio v�lido.");
                return;
            }

            Producto nuevoProducto = null;
            string producto = cmbProducto.SelectedItem.ToString();

            switch (producto)
            {
                case "Silla":
                    if (cmbMaterial.SelectedItem != null && cmbColor.SelectedItem != null)
                    {
                        nuevoProducto = new Silla("Silla", precio, cmbMaterial.SelectedItem.ToString(), cmbColor.SelectedItem.ToString());
                    }
                    break;

                case "Polera":
                    if (cmbTallaPolera.SelectedItem != null && cmbcolorPolera.SelectedItem != null)
                    {
                        nuevoProducto = new Polera("Polera", precio, cmbTallaPolera.SelectedItem.ToString(), cmbcolorPolera.SelectedItem.ToString());
                    }
                    break;

                case "Celular":
                    if (cmbModelo.SelectedItem != null)
                    {
                        nuevoProducto = new Celular("Celular", precio, cmbModelo.SelectedItem.ToString());
                    }
                    break;

                case "Televisor":
                    if (cmbTama�o.SelectedItem != null && cmbMaterial.SelectedItem != null)
                    {
                        nuevoProducto = new Televisor("Televisor", precio, cmbTama�o.SelectedItem.ToString(), cmbMaterial.SelectedItem.ToString());
                    }
                    break;

                case "Colch�n":
                    if (cmbTama�oColchon.SelectedItem != null && cmbMaterialColchon.SelectedItem != null)
                    {
                        nuevoProducto = new Colchon("Colch�n", precio, cmbTama�oColchon.SelectedItem.ToString(), cmbMaterialColchon.SelectedItem.ToString());
                    }
                    break;

                case "Catre":
                    if (cmbTama�oCatre.SelectedItem != null && cmbMaterialCatre.SelectedItem != null)
                    {
                        nuevoProducto = new Catre("Catre", precio, cmbMaterialCatre.SelectedItem.ToString(), cmbTama�oCatre.SelectedItem.ToString());
                    }
                    break;

                case "Zapatos":
                    if (cmbTallaZapato.SelectedItem != null && cmbColorZapato.SelectedItem != null)
                    {
                        nuevoProducto = new Zapatos("Zapatos", precio, cmbTallaZapato.SelectedItem.ToString(), cmbColorZapato.SelectedItem.ToString());
                    }
                    break;

                case "Blusa":
                    if (cmbTallaBlusa.SelectedItem != null && cmbColorBlusa.SelectedItem != null)
                    {
                        nuevoProducto = new Blusa("Blusa", precio, cmbTallaBlusa.SelectedItem.ToString(), cmbColorBlusa.SelectedItem.ToString());
                    }
                    break;

                case "Pantalones":
                    if (cmbTallaPantalon.SelectedItem != null && cmbColorPantalon.SelectedItem != null)
                    {
                        nuevoProducto = new Pantalones("Pantalones", precio, cmbTallaPantalon.SelectedItem.ToString(), cmbColorPantalon.SelectedItem.ToString());
                    }
                    break;

                case "Mochila":
                    if (cmbModeloMochila.SelectedItem != null && cmbColorMochila.SelectedItem != null)
                    {
                        nuevoProducto = new Mochila("Mochila", precio, cmbModeloMochila.SelectedItem.ToString(), cmbColorMochila.SelectedItem.ToString());
                    }
                    break;
            }

            if (nuevoProducto != null)
            {
                listaCompras.Add(nuevoProducto);
                listBoxCompras.Items.Add(nuevoProducto.ToString());
            }
            else
            {
                MessageBox.Show("Por favor, complete todos los campos requeridos.");
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            cmbProducto.SelectedIndex = -1;

            
            OcultarAtributos();

            
            txtPrecio.Clear();

         
            listBoxCompras.Items.Clear();

           
            cmbMaterial.SelectedIndex = -1;
            cmbColor.SelectedIndex = -1;
            cmbModelo.SelectedIndex = -1;
            cmbTallaPolera.SelectedIndex = -1;
            cmbcolorPolera.SelectedIndex = -1;
            cmbTallaZapato.SelectedIndex = -1;
            cmbColorZapato.SelectedIndex = -1;
            cmbTallaBlusa.SelectedIndex = -1;
            cmbColorBlusa.SelectedIndex = -1;
            cmbTallaPantalon.SelectedIndex = -1;
            cmbColorPantalon.SelectedIndex = -1;
            cmbModeloMochila.SelectedIndex = -1;
            cmbColorMochila.SelectedIndex = -1;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            using (StreamWriter writer = new StreamWriter("compras.txt"))
            {
                foreach (var producto in listaCompras)
                {
                    writer.WriteLine(producto.ToString());
                }
            }
            MessageBox.Show("Compras guardadas correctamente.");
        }

        private void lblTama�oColchon_Click(object sender, EventArgs e)
        {

        }
    }
}

    

