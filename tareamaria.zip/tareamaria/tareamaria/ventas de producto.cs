﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace tareamaria
{
    internal class ventas_de_producto
    {
        public class Producto
        {
            public string Nombre { get; set; }
            public decimal Precio { get; set; }

            public Producto(string nombre, decimal precio)
            {
                Nombre = nombre;
                Precio = precio;
            }

            public override string ToString()
            {
                return $"{Nombre} - Precio: {Precio} bs";
            }
            public class Silla : Producto
            {
                public string Material { get; set; }
                public string Color { get; set; }

                public Silla(string nombre, decimal precio, string material, string color)
                    : base(nombre, precio)
                {
                    Material = material;
                    Color = color;
                }

                public override string ToString()
                {
                    return $"{base.ToString()} - Material: {Material}, Color: {Color}";
                }
            }

            public class Celular : Producto
            {
                public string Modelo { get; set; }
                

                public Celular(string nombre, decimal precio, string modelo)
                    : base(nombre, precio)
                {
                    Modelo = modelo;
                    
                }

                public override string ToString()
                {
                    return $"{base.ToString()} - Modelo: {Modelo}";
                }
            }

            public class Televisor : Producto
            {
                public string Tamaño { get; set; }
                public string Marca { get; set; }

                public Televisor(string nombre, decimal precio, string tamaño, string marca)
                    : base(nombre, precio)
                {
                    Tamaño = tamaño;
                    Marca = marca;
                }

                public override string ToString()
                {
                    return $"{base.ToString()} - Tamaño: {Tamaño}, Marca: {Marca}";
                }
            }

            public class Colchon : Producto
            {
                public string Tamaño { get; set; }
                public string Material { get; set; }

                public Colchon(string nombre, decimal precio, string tamaño, string material)
                    : base(nombre, precio)
                {
                    Tamaño = tamaño;
                    Material = material;
                }

                public override string ToString()
                {
                    return $"{base.ToString()} - Tamaño: {Tamaño}, Material: {Material}";
                }
            }

            public class Catre : Producto
            {
                public string Material { get; set; }
                public string Tamaño { get; set; }

                public Catre(string nombre, decimal precio, string material, string tamaño)
                    : base(nombre, precio)
                {
                    Material = material;
                    Tamaño = tamaño;
                }

                public override string ToString()
                {
                    return $"{base.ToString()} - Material: {Material}, Tamaño: {Tamaño}";
                }
            }

            public class Polera : Producto
            {
                public string Talla { get; set; }
                public string Color { get; set; }

                public Polera(string nombre, decimal precio, string talla, string color)
                    : base(nombre, precio)
                {
                    Talla = talla;
                    Color = color;
                }

                public override string ToString()
                {
                    return $"{base.ToString()} - Talla: {Talla}, Color: {Color}";
                }
            }

            public class Pantalones : Producto
            {
                public string Talla { get; set; }
                public string Color { get; set; }

                public Pantalones(string nombre, decimal precio, string talla, string color)
                    : base(nombre, precio)
                {
                    Talla = talla;
                    Color = color;
                }

                public override string ToString()
                {
                    return $"{base.ToString()} - Talla: {Talla}, Color: {Color}";
                }
            }

            public class Zapatos : Producto
            {
                public string Talla { get; set; }
                public string Color { get; set; }

                public Zapatos(string nombre, decimal precio, string talla, string color)
                    : base(nombre, precio)
                {
                    Talla = talla;
                    Color = color;
                }

                public override string ToString()
                {
                    return $"{base.ToString()} - Talla: {Talla}, Color: {Color}";
                }
            }

            public class Blusa : Producto
            {
                public string Talla { get; set; }
                public string Color { get; set; }

                public Blusa(string nombre, decimal precio, string talla, string color)
                    : base(nombre, precio)
                {
                    Talla = talla;
                    Color = color;
                }

                public override string ToString()
                {
                    return $"{base.ToString()} - Talla: {Talla}, Color: {Color}";
                }
            }

            public class Mochila : Producto
            {
                public string Modelo { get; set; }
                public string Color { get; set; }

                public Mochila(string nombre, decimal precio, string modelo, string color)
                    : base(nombre, precio)
                {
                    Modelo = modelo;
                    Color = color;
                }

                public override string ToString()
                {
                    return $"{base.ToString()} - Modelo: {Modelo}, Color: {Color}";
                }
            }
        }
    }
}
