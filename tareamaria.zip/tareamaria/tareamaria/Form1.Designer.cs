﻿namespace tareamaria
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbProducto = new ComboBox();
            label1 = new Label();
            lblColor = new Label();
            lblMaterial = new Label();
            lblPrecio = new Label();
            lblModelo = new Label();
            lblTallaPolera = new Label();
            lblTamaño = new Label();
            lblColorPolera = new Label();
            lblMarca = new Label();
            lblTamañoColchon = new Label();
            lblMaterialColchon = new Label();
            lblColorZapato = new Label();
            lblTallaZapato = new Label();
            lblColorBlusa = new Label();
            lblTallaBlusa = new Label();
            lblColorPantalon = new Label();
            lblTallaPantalon = new Label();
            lblColorMochila = new Label();
            lblModeloMochila = new Label();
            cmbMaterial = new ComboBox();
            cmbColor = new ComboBox();
            cmbModelo = new ComboBox();
            cmbTallaPolera = new ComboBox();
            cmbcolorPolera = new ComboBox();
            cmbTamaño = new ComboBox();
            cmbMarca = new ComboBox();
            cmbTamañoColchon = new ComboBox();
            cmbMaterialColchon = new ComboBox();
            cmbTallaZapato = new ComboBox();
            cmbMaterialCatre = new ComboBox();
            cmbTamañoCatre = new ComboBox();
            lblMaterialCatre = new Label();
            lblTamañoCatre = new Label();
            cmbColorZapato = new ComboBox();
            cmbTallaBlusa = new ComboBox();
            cmbColorBlusa = new ComboBox();
            cmbTallaPantalon = new ComboBox();
            cmbColorPantalon = new ComboBox();
            cmbModeloMochila = new ComboBox();
            cmbColorMochila = new ComboBox();
            btnComprar = new Button();
            btnBorrar = new Button();
            btnMostrar = new Button();
            txtPrecio = new TextBox();
            listBoxCompras = new ListBox();
            btnGuardar = new Button();
            SuspendLayout();
            // 
            // cmbProducto
            // 
            cmbProducto.BackColor = Color.Gainsboro;
            cmbProducto.Font = new Font("Segoe UI Emoji", 9F);
            cmbProducto.FormattingEnabled = true;
            cmbProducto.Location = new Point(192, 48);
            cmbProducto.Name = "cmbProducto";
            cmbProducto.Size = new Size(121, 24);
            cmbProducto.TabIndex = 0;
            cmbProducto.SelectedIndexChanged += cmbProducto_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 11.25F);
            label1.Location = new Point(12, 48);
            label1.Name = "label1";
            label1.Size = new Size(165, 20);
            label1.TabIndex = 1;
            label1.Tag = "";
            label1.Text = "Selecciona un producto";
            // 
            // lblColor
            // 
            lblColor.AutoSize = true;
            lblColor.Font = new Font("Segoe UI Emoji", 11.25F);
            lblColor.Location = new Point(12, 159);
            lblColor.Name = "lblColor";
            lblColor.Size = new Size(43, 20);
            lblColor.TabIndex = 2;
            lblColor.Tag = "";
            lblColor.Text = "color";
            // 
            // lblMaterial
            // 
            lblMaterial.AutoSize = true;
            lblMaterial.Font = new Font("Segoe UI Emoji", 11.25F);
            lblMaterial.Location = new Point(12, 125);
            lblMaterial.Name = "lblMaterial";
            lblMaterial.Size = new Size(64, 20);
            lblMaterial.TabIndex = 3;
            lblMaterial.Tag = "";
            lblMaterial.Text = "material";
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Font = new Font("Segoe UI Emoji", 11.25F);
            lblPrecio.Location = new Point(16, 86);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(50, 20);
            lblPrecio.TabIndex = 4;
            lblPrecio.Tag = "";
            lblPrecio.Text = "Precio";
            // 
            // lblModelo
            // 
            lblModelo.AutoSize = true;
            lblModelo.Font = new Font("Segoe UI Emoji", 11.25F);
            lblModelo.Location = new Point(12, 125);
            lblModelo.Name = "lblModelo";
            lblModelo.Size = new Size(61, 20);
            lblModelo.TabIndex = 5;
            lblModelo.Tag = "";
            lblModelo.Text = "modelo";
            // 
            // lblTallaPolera
            // 
            lblTallaPolera.AutoSize = true;
            lblTallaPolera.Font = new Font("Segoe UI Emoji", 11.25F);
            lblTallaPolera.Location = new Point(12, 125);
            lblTallaPolera.Name = "lblTallaPolera";
            lblTallaPolera.Size = new Size(41, 20);
            lblTallaPolera.TabIndex = 6;
            lblTallaPolera.Tag = "";
            lblTallaPolera.Text = "Talla";
            // 
            // lblTamaño
            // 
            lblTamaño.AutoSize = true;
            lblTamaño.Font = new Font("Segoe UI Emoji", 11.25F);
            lblTamaño.Location = new Point(12, 125);
            lblTamaño.Name = "lblTamaño";
            lblTamaño.Size = new Size(60, 20);
            lblTamaño.TabIndex = 7;
            lblTamaño.Tag = "";
            lblTamaño.Text = "tamaño";
            // 
            // lblColorPolera
            // 
            lblColorPolera.AutoSize = true;
            lblColorPolera.Font = new Font("Segoe UI Emoji", 11.25F);
            lblColorPolera.Location = new Point(12, 159);
            lblColorPolera.Name = "lblColorPolera";
            lblColorPolera.Size = new Size(43, 20);
            lblColorPolera.TabIndex = 8;
            lblColorPolera.Tag = "";
            lblColorPolera.Text = "color";
            // 
            // lblMarca
            // 
            lblMarca.AutoSize = true;
            lblMarca.Font = new Font("Segoe UI Emoji", 11.25F);
            lblMarca.Location = new Point(12, 125);
            lblMarca.Name = "lblMarca";
            lblMarca.Size = new Size(50, 20);
            lblMarca.TabIndex = 9;
            lblMarca.Tag = "";
            lblMarca.Text = "marca";
            // 
            // lblTamañoColchon
            // 
            lblTamañoColchon.AutoSize = true;
            lblTamañoColchon.Font = new Font("Segoe UI Emoji", 11.25F);
            lblTamañoColchon.Location = new Point(12, 125);
            lblTamañoColchon.Name = "lblTamañoColchon";
            lblTamañoColchon.Size = new Size(60, 20);
            lblTamañoColchon.TabIndex = 10;
            lblTamañoColchon.Tag = "";
            lblTamañoColchon.Text = "tamaño";
            lblTamañoColchon.Click += lblTamañoColchon_Click;
            // 
            // lblMaterialColchon
            // 
            lblMaterialColchon.AutoSize = true;
            lblMaterialColchon.Font = new Font("Segoe UI Emoji", 11.25F);
            lblMaterialColchon.Location = new Point(12, 159);
            lblMaterialColchon.Name = "lblMaterialColchon";
            lblMaterialColchon.Size = new Size(64, 20);
            lblMaterialColchon.TabIndex = 11;
            lblMaterialColchon.Tag = "";
            lblMaterialColchon.Text = "material";
            // 
            // lblColorZapato
            // 
            lblColorZapato.AutoSize = true;
            lblColorZapato.Font = new Font("Segoe UI Emoji", 11.25F);
            lblColorZapato.Location = new Point(12, 159);
            lblColorZapato.Name = "lblColorZapato";
            lblColorZapato.Size = new Size(43, 20);
            lblColorZapato.TabIndex = 13;
            lblColorZapato.Tag = "";
            lblColorZapato.Text = "color";
            // 
            // lblTallaZapato
            // 
            lblTallaZapato.AutoSize = true;
            lblTallaZapato.Font = new Font("Segoe UI Emoji", 11.25F);
            lblTallaZapato.Location = new Point(12, 125);
            lblTallaZapato.Name = "lblTallaZapato";
            lblTallaZapato.Size = new Size(41, 20);
            lblTallaZapato.TabIndex = 12;
            lblTallaZapato.Tag = "";
            lblTallaZapato.Text = "Talla";
            // 
            // lblColorBlusa
            // 
            lblColorBlusa.AutoSize = true;
            lblColorBlusa.Font = new Font("Segoe UI Emoji", 11.25F);
            lblColorBlusa.Location = new Point(12, 159);
            lblColorBlusa.Name = "lblColorBlusa";
            lblColorBlusa.Size = new Size(43, 20);
            lblColorBlusa.TabIndex = 15;
            lblColorBlusa.Tag = "";
            lblColorBlusa.Text = "color";
            // 
            // lblTallaBlusa
            // 
            lblTallaBlusa.AutoSize = true;
            lblTallaBlusa.Font = new Font("Segoe UI Emoji", 11.25F);
            lblTallaBlusa.Location = new Point(12, 125);
            lblTallaBlusa.Name = "lblTallaBlusa";
            lblTallaBlusa.Size = new Size(41, 20);
            lblTallaBlusa.TabIndex = 14;
            lblTallaBlusa.Tag = "";
            lblTallaBlusa.Text = "Talla";
            // 
            // lblColorPantalon
            // 
            lblColorPantalon.AutoSize = true;
            lblColorPantalon.Font = new Font("Segoe UI Emoji", 11.25F);
            lblColorPantalon.Location = new Point(12, 159);
            lblColorPantalon.Name = "lblColorPantalon";
            lblColorPantalon.Size = new Size(43, 20);
            lblColorPantalon.TabIndex = 17;
            lblColorPantalon.Tag = "";
            lblColorPantalon.Text = "color";
            // 
            // lblTallaPantalon
            // 
            lblTallaPantalon.AutoSize = true;
            lblTallaPantalon.Font = new Font("Segoe UI Emoji", 11.25F);
            lblTallaPantalon.Location = new Point(12, 125);
            lblTallaPantalon.Name = "lblTallaPantalon";
            lblTallaPantalon.Size = new Size(41, 20);
            lblTallaPantalon.TabIndex = 16;
            lblTallaPantalon.Tag = "";
            lblTallaPantalon.Text = "Talla";
            // 
            // lblColorMochila
            // 
            lblColorMochila.AutoSize = true;
            lblColorMochila.Font = new Font("Segoe UI Emoji", 11.25F);
            lblColorMochila.Location = new Point(12, 159);
            lblColorMochila.Name = "lblColorMochila";
            lblColorMochila.Size = new Size(43, 20);
            lblColorMochila.TabIndex = 18;
            lblColorMochila.Tag = "";
            lblColorMochila.Text = "color";
            // 
            // lblModeloMochila
            // 
            lblModeloMochila.AutoSize = true;
            lblModeloMochila.Font = new Font("Segoe UI Emoji", 11.25F);
            lblModeloMochila.Location = new Point(12, 125);
            lblModeloMochila.Name = "lblModeloMochila";
            lblModeloMochila.Size = new Size(61, 20);
            lblModeloMochila.TabIndex = 19;
            lblModeloMochila.Tag = "";
            lblModeloMochila.Text = "modelo";
            // 
            // cmbMaterial
            // 
            cmbMaterial.Font = new Font("Segoe UI Emoji", 9F);
            cmbMaterial.FormattingEnabled = true;
            cmbMaterial.Location = new Point(91, 125);
            cmbMaterial.Name = "cmbMaterial";
            cmbMaterial.Size = new Size(121, 24);
            cmbMaterial.TabIndex = 20;
            cmbMaterial.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // cmbColor
            // 
            cmbColor.Font = new Font("Segoe UI Emoji", 9F);
            cmbColor.FormattingEnabled = true;
            cmbColor.Location = new Point(91, 155);
            cmbColor.Name = "cmbColor";
            cmbColor.Size = new Size(121, 24);
            cmbColor.TabIndex = 21;
            // 
            // cmbModelo
            // 
            cmbModelo.Font = new Font("Segoe UI Emoji", 9F);
            cmbModelo.FormattingEnabled = true;
            cmbModelo.Location = new Point(91, 125);
            cmbModelo.Name = "cmbModelo";
            cmbModelo.Size = new Size(121, 24);
            cmbModelo.TabIndex = 22;
            // 
            // cmbTallaPolera
            // 
            cmbTallaPolera.Font = new Font("Segoe UI Emoji", 9F);
            cmbTallaPolera.FormattingEnabled = true;
            cmbTallaPolera.Location = new Point(91, 125);
            cmbTallaPolera.Name = "cmbTallaPolera";
            cmbTallaPolera.Size = new Size(121, 24);
            cmbTallaPolera.TabIndex = 23;
            // 
            // cmbcolorPolera
            // 
            cmbcolorPolera.Font = new Font("Segoe UI Emoji", 9F);
            cmbcolorPolera.FormattingEnabled = true;
            cmbcolorPolera.Location = new Point(91, 155);
            cmbcolorPolera.Name = "cmbcolorPolera";
            cmbcolorPolera.Size = new Size(121, 24);
            cmbcolorPolera.TabIndex = 24;
            // 
            // cmbTamaño
            // 
            cmbTamaño.Font = new Font("Segoe UI Emoji", 9F);
            cmbTamaño.FormattingEnabled = true;
            cmbTamaño.Location = new Point(91, 125);
            cmbTamaño.Name = "cmbTamaño";
            cmbTamaño.Size = new Size(121, 24);
            cmbTamaño.TabIndex = 25;
            // 
            // cmbMarca
            // 
            cmbMarca.Font = new Font("Segoe UI Emoji", 9F);
            cmbMarca.FormattingEnabled = true;
            cmbMarca.Location = new Point(91, 155);
            cmbMarca.Name = "cmbMarca";
            cmbMarca.Size = new Size(121, 24);
            cmbMarca.TabIndex = 26;
            // 
            // cmbTamañoColchon
            // 
            cmbTamañoColchon.Font = new Font("Segoe UI Emoji", 9F);
            cmbTamañoColchon.FormattingEnabled = true;
            cmbTamañoColchon.Location = new Point(91, 125);
            cmbTamañoColchon.Name = "cmbTamañoColchon";
            cmbTamañoColchon.Size = new Size(121, 24);
            cmbTamañoColchon.TabIndex = 27;
            // 
            // cmbMaterialColchon
            // 
            cmbMaterialColchon.Font = new Font("Segoe UI Emoji", 9F);
            cmbMaterialColchon.FormattingEnabled = true;
            cmbMaterialColchon.Location = new Point(91, 155);
            cmbMaterialColchon.Name = "cmbMaterialColchon";
            cmbMaterialColchon.Size = new Size(121, 24);
            cmbMaterialColchon.TabIndex = 28;
            // 
            // cmbTallaZapato
            // 
            cmbTallaZapato.Font = new Font("Segoe UI Emoji", 9F);
            cmbTallaZapato.FormattingEnabled = true;
            cmbTallaZapato.Location = new Point(91, 125);
            cmbTallaZapato.Name = "cmbTallaZapato";
            cmbTallaZapato.Size = new Size(121, 24);
            cmbTallaZapato.TabIndex = 29;
            // 
            // cmbMaterialCatre
            // 
            cmbMaterialCatre.Font = new Font("Segoe UI Emoji", 9F);
            cmbMaterialCatre.FormattingEnabled = true;
            cmbMaterialCatre.Location = new Point(91, 155);
            cmbMaterialCatre.Name = "cmbMaterialCatre";
            cmbMaterialCatre.Size = new Size(121, 24);
            cmbMaterialCatre.TabIndex = 33;
            // 
            // cmbTamañoCatre
            // 
            cmbTamañoCatre.Font = new Font("Segoe UI Emoji", 9F);
            cmbTamañoCatre.FormattingEnabled = true;
            cmbTamañoCatre.Location = new Point(91, 125);
            cmbTamañoCatre.Name = "cmbTamañoCatre";
            cmbTamañoCatre.Size = new Size(121, 24);
            cmbTamañoCatre.TabIndex = 32;
            // 
            // lblMaterialCatre
            // 
            lblMaterialCatre.AutoSize = true;
            lblMaterialCatre.Font = new Font("Segoe UI Emoji", 11.25F);
            lblMaterialCatre.Location = new Point(12, 159);
            lblMaterialCatre.Name = "lblMaterialCatre";
            lblMaterialCatre.Size = new Size(64, 20);
            lblMaterialCatre.TabIndex = 31;
            lblMaterialCatre.Tag = "";
            lblMaterialCatre.Text = "material";
            // 
            // lblTamañoCatre
            // 
            lblTamañoCatre.AutoSize = true;
            lblTamañoCatre.Font = new Font("Segoe UI Emoji", 11.25F);
            lblTamañoCatre.Location = new Point(12, 125);
            lblTamañoCatre.Name = "lblTamañoCatre";
            lblTamañoCatre.Size = new Size(60, 20);
            lblTamañoCatre.TabIndex = 30;
            lblTamañoCatre.Tag = "";
            lblTamañoCatre.Text = "tamaño";
            // 
            // cmbColorZapato
            // 
            cmbColorZapato.Font = new Font("Segoe UI Emoji", 9F);
            cmbColorZapato.FormattingEnabled = true;
            cmbColorZapato.Location = new Point(91, 155);
            cmbColorZapato.Name = "cmbColorZapato";
            cmbColorZapato.Size = new Size(121, 24);
            cmbColorZapato.TabIndex = 34;
            // 
            // cmbTallaBlusa
            // 
            cmbTallaBlusa.Font = new Font("Segoe UI Emoji", 9F);
            cmbTallaBlusa.FormattingEnabled = true;
            cmbTallaBlusa.Location = new Point(91, 125);
            cmbTallaBlusa.Name = "cmbTallaBlusa";
            cmbTallaBlusa.Size = new Size(121, 24);
            cmbTallaBlusa.TabIndex = 35;
            // 
            // cmbColorBlusa
            // 
            cmbColorBlusa.Font = new Font("Segoe UI Emoji", 9F);
            cmbColorBlusa.FormattingEnabled = true;
            cmbColorBlusa.Location = new Point(91, 155);
            cmbColorBlusa.Name = "cmbColorBlusa";
            cmbColorBlusa.Size = new Size(121, 24);
            cmbColorBlusa.TabIndex = 36;
            // 
            // cmbTallaPantalon
            // 
            cmbTallaPantalon.Font = new Font("Segoe UI Emoji", 9F);
            cmbTallaPantalon.FormattingEnabled = true;
            cmbTallaPantalon.Location = new Point(91, 125);
            cmbTallaPantalon.Name = "cmbTallaPantalon";
            cmbTallaPantalon.Size = new Size(121, 24);
            cmbTallaPantalon.TabIndex = 37;
            // 
            // cmbColorPantalon
            // 
            cmbColorPantalon.Font = new Font("Segoe UI Emoji", 9F);
            cmbColorPantalon.FormattingEnabled = true;
            cmbColorPantalon.Location = new Point(91, 155);
            cmbColorPantalon.Name = "cmbColorPantalon";
            cmbColorPantalon.Size = new Size(121, 24);
            cmbColorPantalon.TabIndex = 38;
            // 
            // cmbModeloMochila
            // 
            cmbModeloMochila.BackColor = Color.Silver;
            cmbModeloMochila.Font = new Font("Segoe UI Emoji", 9F);
            cmbModeloMochila.FormattingEnabled = true;
            cmbModeloMochila.Location = new Point(91, 125);
            cmbModeloMochila.Name = "cmbModeloMochila";
            cmbModeloMochila.Size = new Size(121, 24);
            cmbModeloMochila.TabIndex = 39;
            // 
            // cmbColorMochila
            // 
            cmbColorMochila.BackColor = Color.Silver;
            cmbColorMochila.Font = new Font("Segoe UI Emoji", 9F);
            cmbColorMochila.FormattingEnabled = true;
            cmbColorMochila.Location = new Point(91, 155);
            cmbColorMochila.Name = "cmbColorMochila";
            cmbColorMochila.Size = new Size(121, 24);
            cmbColorMochila.TabIndex = 40;
            // 
            // btnComprar
            // 
            btnComprar.BackColor = Color.Silver;
            btnComprar.Location = new Point(335, 59);
            btnComprar.Name = "btnComprar";
            btnComprar.Size = new Size(111, 23);
            btnComprar.TabIndex = 41;
            btnComprar.Text = "Comprar";
            btnComprar.UseVisualStyleBackColor = false;
            btnComprar.Click += btnComprar_Click;
            // 
            // btnBorrar
            // 
            btnBorrar.BackColor = Color.Silver;
            btnBorrar.Location = new Point(467, 59);
            btnBorrar.Name = "btnBorrar";
            btnBorrar.Size = new Size(75, 23);
            btnBorrar.TabIndex = 42;
            btnBorrar.Text = "borrar";
            btnBorrar.UseVisualStyleBackColor = false;
            btnBorrar.Click += btnBorrar_Click;
            // 
            // btnMostrar
            // 
            btnMostrar.BackColor = Color.Silver;
            btnMostrar.Location = new Point(192, 19);
            btnMostrar.Name = "btnMostrar";
            btnMostrar.Size = new Size(75, 23);
            btnMostrar.TabIndex = 44;
            btnMostrar.Text = "Mostrar";
            btnMostrar.UseVisualStyleBackColor = false;
            // 
            // txtPrecio
            // 
            txtPrecio.BackColor = Color.Silver;
            txtPrecio.Location = new Point(91, 83);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(100, 23);
            txtPrecio.TabIndex = 45;
            // 
            // listBoxCompras
            // 
            listBoxCompras.BackColor = Color.SeaShell;
            listBoxCompras.FormattingEnabled = true;
            listBoxCompras.ItemHeight = 15;
            listBoxCompras.Location = new Point(236, 100);
            listBoxCompras.Name = "listBoxCompras";
            listBoxCompras.Size = new Size(350, 79);
            listBoxCompras.TabIndex = 46;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.Silver;
            btnGuardar.Location = new Point(564, 59);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 47;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = false;
            btnGuardar.Click += btnGuardar_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.GhostWhite;
            ClientSize = new Size(681, 247);
            Controls.Add(btnGuardar);
            Controls.Add(listBoxCompras);
            Controls.Add(txtPrecio);
            Controls.Add(btnMostrar);
            Controls.Add(btnBorrar);
            Controls.Add(btnComprar);
            Controls.Add(cmbColorMochila);
            Controls.Add(cmbModeloMochila);
            Controls.Add(cmbColorPantalon);
            Controls.Add(cmbTallaPantalon);
            Controls.Add(cmbColorBlusa);
            Controls.Add(cmbTallaBlusa);
            Controls.Add(cmbColorZapato);
            Controls.Add(cmbMaterialCatre);
            Controls.Add(cmbTamañoCatre);
            Controls.Add(lblMaterialCatre);
            Controls.Add(lblTamañoCatre);
            Controls.Add(cmbTallaZapato);
            Controls.Add(cmbMaterialColchon);
            Controls.Add(cmbTamañoColchon);
            Controls.Add(cmbMarca);
            Controls.Add(cmbTamaño);
            Controls.Add(cmbcolorPolera);
            Controls.Add(cmbTallaPolera);
            Controls.Add(cmbModelo);
            Controls.Add(cmbColor);
            Controls.Add(cmbMaterial);
            Controls.Add(lblModeloMochila);
            Controls.Add(lblColorMochila);
            Controls.Add(lblColorPantalon);
            Controls.Add(lblTallaPantalon);
            Controls.Add(lblColorBlusa);
            Controls.Add(lblTallaBlusa);
            Controls.Add(lblColorZapato);
            Controls.Add(lblTallaZapato);
            Controls.Add(lblMaterialColchon);
            Controls.Add(lblTamañoColchon);
            Controls.Add(lblMarca);
            Controls.Add(lblColorPolera);
            Controls.Add(lblTamaño);
            Controls.Add(lblTallaPolera);
            Controls.Add(lblModelo);
            Controls.Add(lblPrecio);
            Controls.Add(lblMaterial);
            Controls.Add(lblColor);
            Controls.Add(label1);
            Controls.Add(cmbProducto);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbProducto;
        private Label label1;
        private Label lblColor;
        private Label lblMaterial;
        private Label lblPrecio;
        private Label lblModelo;
        private Label lblTallaPolera;
        private Label lblTamaño;
        private Label lblColorPolera;
        private Label lblMarca;
        private Label lblTamañoColchon;
        private Label lblMaterialColchon;
        private Label lblColorZapato;
        private Label lblTallaZapato;
        private Label lblColorBlusa;
        private Label lblTallaBlusa;
        private Label lblColorPantalon;
        private Label lblTallaPantalon;
        private Label lblColorMochila;
        private Label lblModeloMochila;
        private ComboBox cmbMaterial;
        private ComboBox cmbColor;
        private ComboBox cmbModelo;
        private ComboBox cmbTallaPolera;
        private ComboBox cmbcolorPolera;
        private ComboBox cmbTamaño;
        private ComboBox cmbMarca;
        private ComboBox cmbTamañoColchon;
        private ComboBox cmbMaterialColchon;
        private ComboBox cmbTallaZapato;
        private ComboBox cmbMaterialCatre;
        private ComboBox cmbTamañoCatre;
        private Label lblMaterialCatre;
        private Label lblTamañoCatre;
        private ComboBox cmbColorZapato;
        private ComboBox cmbTallaBlusa;
        private ComboBox cmbColorBlusa;
        private ComboBox cmbTallaPantalon;
        private ComboBox cmbColorPantalon;
        private ComboBox cmbModeloMochila;
        private ComboBox cmbColorMochila;
        private Button btnComprar;
        private Button btnBorrar;
        private Button btnMostrar;
        private TextBox txtPrecio;
        private ListBox listBoxCompras;
        private Button btnGuardar;
    }
}
